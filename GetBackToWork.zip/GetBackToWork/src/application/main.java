package application;
import bbdd.Conexion;

public class main{
	public main (String[] args) {
		Conexion.conexionBbdd();
	}
}
