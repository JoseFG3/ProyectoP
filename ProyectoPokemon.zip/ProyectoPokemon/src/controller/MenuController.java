package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MenuController {

    @FXML
    private Button btnCaptura;

    @FXML
    private Button btnCenroPokemon;

    @FXML
    private Button btnCombate;

    @FXML
    private Button btnCrianza;

    @FXML
    private Button btnEntrenamiento;

    @FXML
    private Button btnEquipo;

    @FXML
    void irCaptura(ActionEvent event) {

    }

    @FXML
    void irCentroPokemon(ActionEvent event) {

    }

    @FXML
    void irCombate(ActionEvent event) {

    }

    @FXML
    void irCrianza(ActionEvent event) {

    }

    @FXML
    void irEntrenamiento(ActionEvent event) {

    }

    @FXML
    void irEquipo(ActionEvent event) {

    }

}
