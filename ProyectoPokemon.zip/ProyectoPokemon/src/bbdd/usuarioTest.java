package bbdd;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class usuarioTest {

	@Test
	void testLogin() {
		fail("Not yet implemented");
	}

}
